from model.unet_model import UNet
from utils.dataset import ISBI_Loader
from utils.dataset1 import ISBI_Loader1
from torch import optim
import torch.nn as nn
import torch
from tqdm import tqdm
import pandas as pd
import numpy as np
import openpyxl

def train_net(net, device, data_path, model_path, loss_path, epochs=40, batch_size=1, lr=0.00001):
    # 加载训练集
    train_isbi_dataset = ISBI_Loader(data_path)#定义好的一个类，里面定义了如何获取数据集，并且文件夹名字从里面修改
    test_isbi_dataset = ISBI_Loader1(data_path)
    per_epoch_num = len(train_isbi_dataset) / batch_size
    train_loader = torch.utils.data.DataLoader(dataset=train_isbi_dataset,
                                               batch_size=batch_size,
                                               shuffle=True)
    test_loader = torch.utils.data.DataLoader(dataset=test_isbi_dataset,
                                               batch_size=batch_size,
                                               shuffle=True)
    
    # 定义RMSprop算法
    optimizer = optim.RMSprop(net.parameters(), lr=lr, weight_decay=1e-8, momentum=0.9)
    # 定义Loss算法
    criterion = nn.BCEWithLogitsLoss()
    # loss_function = nn.CrossEntropyLoss()
    # best_loss统计，初始化为正无穷
    best_loss = float('inf')
    # 训练epochs次
    train_loss=[]
    test_loss=[]
    with tqdm(total=epochs*per_epoch_num) as pbar:
        for epoch in range(epochs):
            # 训练模式
            net.train()
            running_loss = 0.0
            # 按照batch_size开始训练
            for step, data in enumerate(train_loader, start=0):
                image,label = data
                optimizer.zero_grad()
                # 将数据拷贝到device中
                image = image.to(device=device, dtype=torch.float32)
                label = label.to(device=device, dtype=torch.float32)
                # 使用网络参数，输出预测结果
                pred = net(image)
                # 计算loss
                loss = criterion(pred, label)
                # loss = loss_function(pred, label)
                running_loss += loss.item()
                
                # print('{}/{}：Loss/train'.format(epoch + 1, epochs), loss.item())
                
                # 保存loss值最小的网络参数
                if loss < best_loss:
                    best_loss = loss
                    # model_path = '/user-data/UNET/result/data200/best_model_200.pth'
                    torch.save(net.state_dict(), model_path)
                
                # 更新参数
                loss.backward()
                optimizer.step()
                pbar.update(1)
            #计算每个epoch的 loss    
            loss_ = running_loss / step
            train_loss.append(loss_)
            print(loss_)
            
            net.eval()
            testing_loss = 0.0
            # 按照batch_size开始训练
            for step, data in enumerate(test_loader, start=0):
                image,label = data
                image = image.to(device=device, dtype=torch.float32)
                label = label.to(device=device, dtype=torch.float32)
                pred = net(image)
                loss = criterion(pred, label)
                testing_loss += loss.item()
            loss1 = testing_loss / step
            test_loss.append(loss1)
            
    dict_ = {'train_loss':train_loss,'test_loss':test_loss}
    df = pd.DataFrame(dict_)
    df.to_excel(loss_path,index = 0)
    print(df)
    
    
    
if __name__ == "__main__":
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    # 加载网络，图片单通道1，分类为1。
    net = UNet(n_channels=1, n_classes=1)  # todo edit input_channels n_classes
    # 将网络拷贝到deivce中
    net.to(device=device)
    # 指定训练集地址，开始训练
    
    data_path="/user-data/UNET/20"
    model_path = "/user-data/UNET/result/data20/best_model20.pth"
    loss_path = "/user-data/UNET/result/data20/loss.xlsx"
    print("进度条出现卡着不动不是程序问题，是他正在计算，请耐心等待")
    train_net(net, device, data_path, model_path, loss_path,epochs=150, batch_size=6,lr=0.00001)