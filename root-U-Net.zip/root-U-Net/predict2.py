import glob
import numpy as np
import torch
import os
import cv2
from model.unet_model import UNet
import time

def Image_list(ori_image):
    "滑窗采样，步长为512，窗口大小为552*552"
    h_step = ori_image.shape[0] // 512
    w_step = ori_image.shape[1] // 512

    h_rest = -(ori_image.shape[0] - 512 * h_step)
    w_rest = -(ori_image.shape[1] - 512 * w_step)

    top_size, bottom_size, left_size, right_size = (20, 20, 20, 20)
    ori_image = cv2.copyMakeBorder(ori_image, top_size, bottom_size, left_size, right_size, borderType=cv2.BORDER_REFLECT)
    # print(ori_image.shape)
    image_list = []
    predict_list = []
    # 循环切图
    for h in range(h_step):
        for w in range(w_step):

            n = 512+40
            image_sample = ori_image[(h * 512):(h * 512 + 512+40),
                           (w * 512):(w * 512 + 512+40), :]
            image_list.append(image_sample)
            image_list.append(ori_image[-(512+40):, (w * 512):(w * 512 + 512+40), :])
        image_list.append(ori_image[(h * 512):(h * 512 + 512+40), -(512+40):, :])
    image_list.append(ori_image[-(512+40):, -(512+40):, :])
    return image_list

def combine_image(ori_image):
    "拼接部分，将每个窗口中心512*512部位进行取样拼接"
    h_step = ori_image.shape[0] // 512
    w_step = ori_image.shape[1] // 512

    h_rest = -(ori_image.shape[0] - 512 * h_step)
    w_rest = -(ori_image.shape[1] - 512 * w_step)

    count_temp = 0
    tmp = np.ones([ori_image.shape[0], ori_image.shape[1]])
    #print('tmp shape: ', tmp.shape)
    for h in range(h_step):
        for w in range(w_step):
            tmp[
            h * 512:(h + 1) * 512,
            w * 512:(w + 1) * 512
            ] = predict_list[count_temp][20:532,20:532]
            count_temp += 1
            tmp[h_rest:, (w * 512):(w * 512 + 512)] = predict_list[count_temp][h_rest-20:-20, 20:532]
            count_temp += 1
        tmp[h * 512:(h + 1) * 512, w_rest:] = predict_list[count_temp][20:532, w_rest-20:-20]
        count_temp += 1
    # tmp[h_rest:, w_rest:] = predict_list[count_temp][h_rest:, w_rest:]
    tmp[-512:, -512:] = predict_list[count_temp][20:532, 20:532]
    return tmp
if __name__ == "__main__":
    t1 = time.perf_counter()
    # 选择设备，有cuda用cuda，没有就用cpu
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(device)
    # 加载网络，图片单通道，分类为1。
    net = UNet(n_channels=1, n_classes=1)
    # 将网络拷贝到deivce中
    net.to(device=device)
    # 加载模型参数
    model_path = r'./U_Net/best_model300.pth'
    net.load_state_dict(torch.load(model_path, map_location=device))
    # 测试模式
    net.eval()
   
    print('开始预测')
    # 读取所有图片路径
    tests_path = glob.glob(r'》/TU/A15CK_4/*.jpg')
#     for i in os.listdir('/autodl-nas/1_98/datat10all'):
#         print(i)
        
    save_path = r'./TU/pre/'
    if not os.path.exists(save_path):
        os.mkdir(save_path)
    # 遍历素有图片
    for test_path in tests_path:
        print(test_path)
        # 保存结果地址
        save_res_path = save_path + str(test_path.split('/')[-1]).split('.')[0] + '.png'
        
        # 读取图片
        image = cv2.imread(test_path)
#         origin_shape = image.shape
#         print(origin_shape)
        image_list = Image_list(image)#获得图片列表
    #预测
        predict_list = []
        for img in image_list:
            img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
            # img = cv2.resize(img, (512, 512))
            # 转为batch为1，通道为1，大小为512*512的数组
            img = img.reshape(1, 1, img.shape[0], img.shape[1])
            # 转为tensor
            img_tensor = torch.from_numpy(img)
            # 将tensor拷贝到device中，只用cpu就是拷贝到cpu中，用cuda就是拷贝到cuda中。
            img_tensor = img_tensor.to(device=device, dtype=torch.float32)
            # 预测
            pred = net(img_tensor)
            # 提取结果
            pred = np.array(pred.data.cpu()[0])[0]
            # 处理结果
            pred[pred >= 0.5] = 255
            pred[pred < 0.5] = 0
            predict_list.append(pred)
            
        # 保存图片
#         pred = cv2.resize(pred, (origin_shape[1], origin_shape[0]), interpolation=cv2.INTER_NEAREST)#最近插值法
        image_res = combine_image(image)
        thresh, image_pre = cv2.threshold(image_res, 0, 255, cv2.THRESH_BINARY_INV)
        cv2.imwrite(save_res_path, image_pre)
        # cv2.imwrite(save_res_path, image_res)
    print(time.perf_counter() - t1)